package com.academia.gestion.sistema_academico.estudiante;

import com.academia.gestion.sistema_academico.events.BeforeDeleteEstudiante;
import com.academia.gestion.sistema_academico.util.NotFoundException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.data.domain.Sort;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.then;
import static org.mockito.Mockito.never;

@ExtendWith(MockitoExtension.class)
@DisplayName("EstudianteService — tests unitarios")
class EstudianteServiceTest {

    @Mock
    private EstudianteRepository estudianteRepository;

    @Mock
    private ApplicationEventPublisher publisher;

    @InjectMocks
    private EstudianteService estudianteService;

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    private Estudiante estudianteEntity(String codigo) {
        Estudiante e = new Estudiante();
        e.setCodigo(codigo);
        e.setNombre("Juan");
        e.setApellido("Pérez");
        e.setEmail("juan@correo.com");
        e.setSemestre("2024-1");
        return e;
    }

    private EstudianteDTO estudianteDTO(String codigo) {
        EstudianteDTO dto = new EstudianteDTO();
        dto.setCodigo(codigo);
        dto.setNombre("Juan");
        dto.setApellido("Pérez");
        dto.setEmail("juan@correo.com");
        dto.setSemestre("2024-1");
        return dto;
    }

    // =========================================================================
    // findAll
    // =========================================================================

    @Nested
    @DisplayName("findAll()")
    class FindAll {

        @Test
        @DisplayName("retorna lista de DTOs mapeados correctamente")
        void findAll_returnsMappedList() {
            Estudiante e = estudianteEntity("EST-001");
            given(estudianteRepository.findAll(Sort.by("codigo"))).willReturn(List.of(e));

            List<EstudianteDTO> result = estudianteService.findAll();

            assertThat(result).hasSize(1);
            assertThat(result.get(0).getCodigo()).isEqualTo("EST-001");
            assertThat(result.get(0).getNombre()).isEqualTo("Juan");
        }

        @Test
        @DisplayName("retorna lista vacía cuando no hay estudiantes")
        void findAll_returnsEmptyList() {
            given(estudianteRepository.findAll(Sort.by("codigo"))).willReturn(List.of());

            List<EstudianteDTO> result = estudianteService.findAll();

            assertThat(result).isEmpty();
        }
    }

    // =========================================================================
    // get
    // =========================================================================

    @Nested
    @DisplayName("get(codigo)")
    class Get {

        @Test
        @DisplayName("caso feliz: retorna DTO cuando el estudiante existe")
        void get_returnsDTO_whenFound() {
            Estudiante e = estudianteEntity("EST-001");
            given(estudianteRepository.findById("EST-001")).willReturn(Optional.of(e));

            EstudianteDTO result = estudianteService.get("EST-001");

            assertThat(result.getCodigo()).isEqualTo("EST-001");
            assertThat(result.getEmail()).isEqualTo("juan@correo.com");
        }

        @Test
        @DisplayName("lanza NotFoundException cuando el estudiante no existe")
        void get_throwsNotFound_whenMissing() {
            given(estudianteRepository.findById("EST-999")).willReturn(Optional.empty());

            assertThatThrownBy(() -> estudianteService.get("EST-999"))
                    .isInstanceOf(NotFoundException.class);
        }
    }

    // =========================================================================
    // create
    // =========================================================================

    @Nested
    @DisplayName("create(EstudianteDTO)")
    class Create {

        @Test
        @DisplayName("persiste la entidad y retorna el código generado")
        void create_savesEntityAndReturnsCodigo() {
            EstudianteDTO dto = estudianteDTO("EST-001");
            Estudiante saved = estudianteEntity("EST-001");
            given(estudianteRepository.save(any(Estudiante.class))).willReturn(saved);

            String result = estudianteService.create(dto);

            assertThat(result).isEqualTo("EST-001");
            ArgumentCaptor<Estudiante> captor = ArgumentCaptor.forClass(Estudiante.class);
            then(estudianteRepository).should().save(captor.capture());
            assertThat(captor.getValue().getCodigo()).isEqualTo("EST-001");
            assertThat(captor.getValue().getNombre()).isEqualTo("Juan");
        }
    }

    // =========================================================================
    // update
    // =========================================================================

    @Nested
    @DisplayName("update(codigo, EstudianteDTO)")
    class Update {

        @Test
        @DisplayName("caso feliz: actualiza los campos del estudiante existente")
        void update_updatesEntity_whenFound() {
            Estudiante existing = estudianteEntity("EST-001");
            given(estudianteRepository.findById("EST-001")).willReturn(Optional.of(existing));

            EstudianteDTO dto = estudianteDTO("EST-001");
            dto.setNombre("Carlos");
            dto.setEmail("carlos@correo.com");

            estudianteService.update("EST-001", dto);

            ArgumentCaptor<Estudiante> captor = ArgumentCaptor.forClass(Estudiante.class);
            then(estudianteRepository).should().save(captor.capture());
            assertThat(captor.getValue().getNombre()).isEqualTo("Carlos");
            assertThat(captor.getValue().getEmail()).isEqualTo("carlos@correo.com");
        }

        @Test
        @DisplayName("lanza NotFoundException cuando el estudiante no existe")
        void update_throwsNotFound_whenMissing() {
            given(estudianteRepository.findById("EST-999")).willReturn(Optional.empty());

            assertThatThrownBy(() -> estudianteService.update("EST-999", estudianteDTO("EST-999")))
                    .isInstanceOf(NotFoundException.class);

            then(estudianteRepository).should(never()).save(any());
        }
    }

    // =========================================================================
    // delete
    // =========================================================================

    @Nested
    @DisplayName("delete(codigo)")
    class Delete {

        @Test
        @DisplayName("caso feliz: publica evento y elimina al estudiante")
        void delete_publishesEventAndDeletes_whenFound() {
            Estudiante e = estudianteEntity("EST-001");
            given(estudianteRepository.findById("EST-001")).willReturn(Optional.of(e));

            estudianteService.delete("EST-001");

            ArgumentCaptor<BeforeDeleteEstudiante> eventCaptor = ArgumentCaptor.forClass(BeforeDeleteEstudiante.class);
            then(publisher).should().publishEvent(eventCaptor.capture());
            assertThat(eventCaptor.getValue().getCodigo()).isEqualTo("EST-001");

            then(estudianteRepository).should().delete(e);
        }

        @Test
        @DisplayName("lanza NotFoundException y no publica evento cuando no existe")
        void delete_throwsNotFound_whenMissing() {
            given(estudianteRepository.findById("EST-999")).willReturn(Optional.empty());

            assertThatThrownBy(() -> estudianteService.delete("EST-999"))
                    .isInstanceOf(NotFoundException.class);

            then(publisher).should(never()).publishEvent(any());
            then(estudianteRepository).should(never()).delete(any(Estudiante.class));
        }
    }

    // =========================================================================
    // codigoExists
    // =========================================================================

    @Nested
    @DisplayName("codigoExists(codigo)")
    class CodigoExists {

        @Test
        @DisplayName("retorna true cuando el código existe (case-insensitive)")
        void codigoExists_returnsTrue() {
            given(estudianteRepository.existsByCodigoIgnoreCase("EST-001")).willReturn(true);
            assertThat(estudianteService.codigoExists("EST-001")).isTrue();
        }

        @Test
        @DisplayName("retorna false cuando el código no existe")
        void codigoExists_returnsFalse() {
            given(estudianteRepository.existsByCodigoIgnoreCase("EST-999")).willReturn(false);
            assertThat(estudianteService.codigoExists("EST-999")).isFalse();
        }
    }

    // =========================================================================
    // nombreExists
    // =========================================================================

    @Nested
    @DisplayName("nombreExists(nombre)")
    class NombreExists {

        @Test
        @DisplayName("retorna true cuando el nombre existe (case-insensitive)")
        void nombreExists_returnsTrue() {
            given(estudianteRepository.existsByNombreIgnoreCase("Juan")).willReturn(true);
            assertThat(estudianteService.nombreExists("Juan")).isTrue();
        }

        @Test
        @DisplayName("retorna false cuando el nombre no existe")
        void nombreExists_returnsFalse() {
            given(estudianteRepository.existsByNombreIgnoreCase("Pedro")).willReturn(false);
            assertThat(estudianteService.nombreExists("Pedro")).isFalse();
        }
    }

    // =========================================================================
    // emailExists
    // =========================================================================

    @Nested
    @DisplayName("emailExists(email)")
    class EmailExists {

        @Test
        @DisplayName("retorna true cuando el email existe (case-insensitive)")
        void emailExists_returnsTrue() {
            given(estudianteRepository.existsByEmailIgnoreCase("juan@correo.com")).willReturn(true);
            assertThat(estudianteService.emailExists("juan@correo.com")).isTrue();
        }

        @Test
        @DisplayName("retorna false cuando el email no existe")
        void emailExists_returnsFalse() {
            given(estudianteRepository.existsByEmailIgnoreCase("noexiste@correo.com")).willReturn(false);
            assertThat(estudianteService.emailExists("noexiste@correo.com")).isFalse();
        }
    }
}
