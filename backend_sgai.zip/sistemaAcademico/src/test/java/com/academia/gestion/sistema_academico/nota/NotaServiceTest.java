package com.academia.gestion.sistema_academico.nota;

import com.academia.gestion.sistema_academico.estudiante.Estudiante;
import com.academia.gestion.sistema_academico.estudiante.EstudianteRepository;
import com.academia.gestion.sistema_academico.events.BeforeDeleteEstudiante;
import com.academia.gestion.sistema_academico.util.NotFoundException;
import com.academia.gestion.sistema_academico.util.ReferencedException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Sort;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.then;
import static org.mockito.Mockito.never;

@ExtendWith(MockitoExtension.class)
@DisplayName("NotaService — tests unitarios")
class NotaServiceTest {

    @Mock
    private NotaRepository notaRepository;

    @Mock
    private EstudianteRepository estudianteRepository;

    @InjectMocks
    private NotaService notaService;

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    private Estudiante estudianteEntity(String codigo) {
        Estudiante e = new Estudiante();
        e.setCodigo(codigo);
        e.setNombre("Juan");
        e.setApellido("Pérez");
        e.setEmail("juan@correo.com");
        e.setSemestre("2024-1");
        return e;
    }

    private Nota notaEntity(Long id, Estudiante estudiante) {
        Nota n = new Nota();
        n.setId(id);
        n.setCurso("Matemáticas");
        n.setValor(18.5);
        n.setCreditos(3);
        n.setTipo("PARCIAL");
        n.setNotaEstudiante(estudiante);
        return n;
    }

    private NotaDTO notaDTO(String codigoEstudiante) {
        NotaDTO dto = new NotaDTO();
        dto.setCurso("Matemáticas");
        dto.setValor(18.5);
        dto.setCreditos(3);
        dto.setTipo("PARCIAL");
        dto.setNotaEstudiante(codigoEstudiante);
        return dto;
    }

    // =========================================================================
    // findAll
    // =========================================================================

    @Nested
    @DisplayName("findAll()")
    class FindAll {

        @Test
        @DisplayName("retorna lista de DTOs mapeados correctamente")
        void findAll_returnsMappedList() {
            Estudiante e = estudianteEntity("EST-001");
            Nota n = notaEntity(1L, e);
            given(notaRepository.findAll(Sort.by("id"))).willReturn(List.of(n));

            List<NotaDTO> result = notaService.findAll();

            assertThat(result).hasSize(1);
            assertThat(result.get(0).getId()).isEqualTo(1L);
            assertThat(result.get(0).getCurso()).isEqualTo("Matemáticas");
            assertThat(result.get(0).getNotaEstudiante()).isEqualTo("EST-001");
        }

        @Test
        @DisplayName("retorna lista vacía cuando no hay notas")
        void findAll_returnsEmptyList() {
            given(notaRepository.findAll(Sort.by("id"))).willReturn(List.of());

            List<NotaDTO> result = notaService.findAll();

            assertThat(result).isEmpty();
        }

        @Test
        @DisplayName("mapea notaEstudiante como null cuando la nota no tiene estudiante")
        void findAll_mapsNullEstudiante() {
            Nota n = notaEntity(2L, null);
            given(notaRepository.findAll(Sort.by("id"))).willReturn(List.of(n));

            List<NotaDTO> result = notaService.findAll();

            assertThat(result.get(0).getNotaEstudiante()).isNull();
        }
    }

    // =========================================================================
    // get
    // =========================================================================

    @Nested
    @DisplayName("get(id)")
    class Get {

        @Test
        @DisplayName("caso feliz: retorna DTO cuando la nota existe")
        void get_returnsDTO_whenFound() {
            Estudiante e = estudianteEntity("EST-001");
            Nota n = notaEntity(1L, e);
            given(notaRepository.findById(1L)).willReturn(Optional.of(n));

            NotaDTO result = notaService.get(1L);

            assertThat(result.getId()).isEqualTo(1L);
            assertThat(result.getValor()).isEqualTo(18.5);
            assertThat(result.getNotaEstudiante()).isEqualTo("EST-001");
        }

        @Test
        @DisplayName("lanza NotFoundException cuando la nota no existe")
        void get_throwsNotFound_whenMissing() {
            given(notaRepository.findById(99L)).willReturn(Optional.empty());

            assertThatThrownBy(() -> notaService.get(99L))
                    .isInstanceOf(NotFoundException.class);
        }
    }

    // =========================================================================
    // create
    // =========================================================================

    @Nested
    @DisplayName("create(NotaDTO)")
    class Create {

        @Test
        @DisplayName("persiste la nota y retorna el id generado")
        void create_savesEntityAndReturnsId() {
            Estudiante e = estudianteEntity("EST-001");
            NotaDTO dto = notaDTO("EST-001");

            Nota savedNota = notaEntity(1L, e);
            given(estudianteRepository.findById("EST-001")).willReturn(Optional.of(e));
            given(notaRepository.save(any(Nota.class))).willReturn(savedNota);

            Long result = notaService.create(dto);

            assertThat(result).isEqualTo(1L);
            ArgumentCaptor<Nota> captor = ArgumentCaptor.forClass(Nota.class);
            then(notaRepository).should().save(captor.capture());
            assertThat(captor.getValue().getCurso()).isEqualTo("Matemáticas");
            assertThat(captor.getValue().getNotaEstudiante()).isEqualTo(e);
        }

        @Test
        @DisplayName("lanza NotFoundException cuando el estudiante referenciado no existe")
        void create_throwsNotFound_whenEstudianteMissing() {
            NotaDTO dto = notaDTO("EST-999");
            given(estudianteRepository.findById("EST-999")).willReturn(Optional.empty());

            assertThatThrownBy(() -> notaService.create(dto))
                    .isInstanceOf(NotFoundException.class)
                    .hasMessageContaining("notaEstudiante not found");

            then(notaRepository).should(never()).save(any());
        }
    }

    // =========================================================================
    // update
    // =========================================================================

    @Nested
    @DisplayName("update(id, NotaDTO)")
    class Update {

        @Test
        @DisplayName("caso feliz: actualiza los campos de la nota existente")
        void update_updatesEntity_whenFound() {
            Estudiante e = estudianteEntity("EST-001");
            Nota existing = notaEntity(1L, e);
            given(notaRepository.findById(1L)).willReturn(Optional.of(existing));
            given(estudianteRepository.findById("EST-001")).willReturn(Optional.of(e));

            NotaDTO dto = notaDTO("EST-001");
            dto.setCurso("Física");
            dto.setValor(15.0);

            notaService.update(1L, dto);

            ArgumentCaptor<Nota> captor = ArgumentCaptor.forClass(Nota.class);
            then(notaRepository).should().save(captor.capture());
            assertThat(captor.getValue().getCurso()).isEqualTo("Física");
            assertThat(captor.getValue().getValor()).isEqualTo(15.0);
        }

        @Test
        @DisplayName("lanza NotFoundException cuando la nota no existe")
        void update_throwsNotFound_whenNotaMissing() {
            given(notaRepository.findById(99L)).willReturn(Optional.empty());

            assertThatThrownBy(() -> notaService.update(99L, notaDTO("EST-001")))
                    .isInstanceOf(NotFoundException.class);

            then(notaRepository).should(never()).save(any());
        }

        @Test
        @DisplayName("lanza NotFoundException cuando el estudiante referenciado no existe al actualizar")
        void update_throwsNotFound_whenEstudianteMissingOnUpdate() {
            Estudiante e = estudianteEntity("EST-001");
            Nota existing = notaEntity(1L, e);
            given(notaRepository.findById(1L)).willReturn(Optional.of(existing));
            given(estudianteRepository.findById("EST-999")).willReturn(Optional.empty());

            NotaDTO dto = notaDTO("EST-999");

            assertThatThrownBy(() -> notaService.update(1L, dto))
                    .isInstanceOf(NotFoundException.class)
                    .hasMessageContaining("notaEstudiante not found");
        }
    }

    // =========================================================================
    // delete
    // =========================================================================

    @Nested
    @DisplayName("delete(id)")
    class Delete {

        @Test
        @DisplayName("caso feliz: elimina la nota existente")
        void delete_deletesNota_whenFound() {
            Estudiante e = estudianteEntity("EST-001");
            Nota n = notaEntity(1L, e);
            given(notaRepository.findById(1L)).willReturn(Optional.of(n));

            notaService.delete(1L);

            then(notaRepository).should().delete(n);
        }

        @Test
        @DisplayName("lanza NotFoundException cuando la nota no existe")
        void delete_throwsNotFound_whenMissing() {
            given(notaRepository.findById(99L)).willReturn(Optional.empty());

            assertThatThrownBy(() -> notaService.delete(99L))
                    .isInstanceOf(NotFoundException.class);

            then(notaRepository).should(never()).delete(any(Nota.class));
        }
    }

    // =========================================================================
    // on(BeforeDeleteEstudiante) — Event Listener
    // =========================================================================

    @Nested
    @DisplayName("on(BeforeDeleteEstudiante)")
    class OnBeforeDeleteEstudiante {

        @Test
        @DisplayName("caso feliz: no lanza excepción si el estudiante no tiene notas")
        void on_doesNotThrow_whenNoNotasReferenced() {
            given(notaRepository.findFirstByNotaEstudianteCodigo("EST-001")).willReturn(null);

            BeforeDeleteEstudiante event = new BeforeDeleteEstudiante("EST-001");

            // No debe lanzar excepción
            notaService.on(event);
        }

        @Test
        @DisplayName("lanza ReferencedException si el estudiante tiene notas asociadas")
        void on_throwsReferencedException_whenNotasReferenced() {
            Estudiante e = estudianteEntity("EST-001");
            Nota notaReferenciada = notaEntity(5L, e);
            given(notaRepository.findFirstByNotaEstudianteCodigo("EST-001"))
                    .willReturn(notaReferenciada);

            BeforeDeleteEstudiante event = new BeforeDeleteEstudiante("EST-001");

            assertThatThrownBy(() -> notaService.on(event))
                    .isInstanceOf(ReferencedException.class)
                    .satisfies(ex -> {
                        ReferencedException re = (ReferencedException) ex;
                        assertThat(re.getKey()).isEqualTo("estudiante.nota.notaEstudiante.referenced");
                        assertThat(re.getParams()).contains(5L);
                    });
        }
    }
}
