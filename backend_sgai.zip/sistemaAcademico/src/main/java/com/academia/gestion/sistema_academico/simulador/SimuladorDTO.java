package com.academia.gestion.sistema_academico.simulador;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class SimuladorDTO {

    private double promedioActual;
    private double promedioSimulado;
    private double diferencia;
    private List<String> reglasActuales;
    private List<String> reglasSimuladas;
    private String cambioEstado;
}