package com.academia.gestion.sistema_academico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class SistemaAcademicoApplication {

    public static void main(final String[] args) {
        SpringApplication.run(SistemaAcademicoApplication.class, args);
    }

}
