package com.academia.gestion.sistema_academico.simulador;

import com.academia.gestion.sistema_academico.estudiante.Estudiante;
import com.academia.gestion.sistema_academico.estudiante.EstudianteRepository;
import com.academia.gestion.sistema_academico.nota.Nota;
import com.academia.gestion.sistema_academico.rules.MotorDeReglas;
import com.academia.gestion.sistema_academico.rules.core.CalculadoraPromedio;
import com.academia.gestion.sistema_academico.rules.core.ResultadoEvaluacion;
import com.academia.gestion.sistema_academico.util.NotFoundException;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
public class SimuladorService {

    private final EstudianteRepository estudianteRepository;
    private final MotorDeReglas motorDeReglas;

    public SimuladorService(final EstudianteRepository estudianteRepository,
            final MotorDeReglas motorDeReglas) {
        this.estudianteRepository = estudianteRepository;
        this.motorDeReglas = motorDeReglas;
    }

    public SimuladorDTO simular(final String codigo, final SimulacionRequest request) {
        final Estudiante estudianteReal = estudianteRepository.findById(codigo)
                .orElseThrow(NotFoundException::new);

        final double promedioActual = CalculadoraPromedio.calcular(estudianteReal);
        final List<ResultadoEvaluacion> reglasActuales = motorDeReglas.evaluarTodas(estudianteReal);

        final Estudiante estudianteSimulado = clonarEstudiante(estudianteReal);
        final Nota notaHipotetica = new Nota();
        notaHipotetica.setCurso(request.getCurso());
        notaHipotetica.setValor(request.getValor());
        notaHipotetica.setCreditos(request.getCreditos());
        notaHipotetica.setTipo("PARCIAL");
        notaHipotetica.setSemestre(estudianteReal.getSemestre());
        notaHipotetica.setNotaEstudiante(estudianteSimulado);
        estudianteSimulado.getEstudiante().add(notaHipotetica);

        final double promedioSimulado = CalculadoraPromedio.calcular(estudianteSimulado);
        final List<ResultadoEvaluacion> reglasSimuladas = motorDeReglas.evaluarTodas(estudianteSimulado);

        final SimuladorDTO dto = new SimuladorDTO();
        dto.setPromedioActual(promedioActual);
        dto.setPromedioSimulado(promedioSimulado);
        dto.setDiferencia(promedioSimulado - promedioActual);
        dto.setReglasActuales(reglasActuales.stream().map(ResultadoEvaluacion::regla).toList());
        dto.setReglasSimuladas(reglasSimuladas.stream().map(ResultadoEvaluacion::regla).toList());
        dto.setCambioEstado(determinarCambioEstado(promedioActual, promedioSimulado));

        return dto;
    }

    private Estudiante clonarEstudiante(final Estudiante original) {
        final Estudiante clon = new Estudiante();
        clon.setCodigo(original.getCodigo());
        clon.setNombre(original.getNombre());
        clon.setApellido(original.getApellido());
        clon.setEmail(original.getEmail());
        clon.setSemestre(original.getSemestre());

        final Set<Nota> notasClonadas = new HashSet<>();
        for (Nota notaOriginal : original.getEstudiante()) {
            final Nota notaClon = new Nota();
            notaClon.setId(notaOriginal.getId());
            notaClon.setCurso(notaOriginal.getCurso());
            notaClon.setValor(notaOriginal.getValor());
            notaClon.setCreditos(notaOriginal.getCreditos());
            notaClon.setTipo(notaOriginal.getTipo());
            notaClon.setSemestre(notaOriginal.getSemestre());
            notaClon.setNotaEstudiante(clon);
            notasClonadas.add(notaClon);
        }
        clon.setEstudiante(notasClonadas);
        return clon;
    }

    private String determinarCambioEstado(final double promedioActual, final double promedioSimulado) {
        final boolean aprobabaAntes = promedioActual >= 14;
        final boolean aprobaraDespues = promedioSimulado >= 14;

        if (aprobabaAntes == aprobaraDespues) {
            return promedioSimulado > promedioActual ? "MEJORA"
                    : promedioSimulado < promedioActual ? "EMPEORA" : "SIN_CAMBIO";
        }
        return aprobaraDespues ? "MEJORA_ESTADO" : "EMPEORA_ESTADO";
    }
}