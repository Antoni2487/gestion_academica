package com.academia.gestion.sistema_academico.nota;

import org.springframework.data.jpa.repository.JpaRepository;


public interface NotaRepository extends JpaRepository<Nota, Long> {

    Nota findFirstByNotaEstudianteCodigo(String codigo);

}
