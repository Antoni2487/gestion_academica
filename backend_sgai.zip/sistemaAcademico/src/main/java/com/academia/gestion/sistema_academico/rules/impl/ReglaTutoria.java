package com.academia.gestion.sistema_academico.rules.impl;

import com.academia.gestion.sistema_academico.estudiante.Estudiante;
import com.academia.gestion.sistema_academico.rules.core.CalculadoraPromedio;
import com.academia.gestion.sistema_academico.rules.core.NivelAlerta;
import com.academia.gestion.sistema_academico.rules.core.ReglaAcademica;
import com.academia.gestion.sistema_academico.rules.core.ResultadoEvaluacion;

public class ReglaTutoria implements ReglaAcademica {

    @Override
    public ResultadoEvaluacion evaluar(Estudiante estudiante) {
        long desaprobados = CalculadoraPromedio.contarCursosDesaprobados(estudiante, 14);
        if (desaprobados > 2) {
            return new ResultadoEvaluacion(
                    "ReglaTutoria",
                    "Requiere tutoría — " + desaprobados + " cursos desaprobados",
                    NivelAlerta.CRITICO);
        }
        return null;
    }
}