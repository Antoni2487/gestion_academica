package com.academia.gestion.sistema_academico.estudiante;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import java.util.List;
import com.academia.gestion.sistema_academico.rules.core.ResultadoEvaluacion;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/api/estudiantes", produces = MediaType.APPLICATION_JSON_VALUE)
@Tag(name = "Estudiantes", description = "Gestion de estudiantes del sistema academico")
public class EstudianteResource {

        private final EstudianteService estudianteService;

        public EstudianteResource(final EstudianteService estudianteService) {
                this.estudianteService = estudianteService;
        }

        @GetMapping
        @Operation(summary = "Listar todos los estudiantes", description = "Retorna la lista completa de estudiantes ordenada por codigo.")
        @ApiResponse(responseCode = "200", description = "Lista de estudiantes obtenida exitosamente")
        public ResponseEntity<List<EstudianteDTO>> getAllEstudiantes() {
                return ResponseEntity.ok(estudianteService.findAll());
        }

        @GetMapping("/{codigo}")
        @Operation(summary = "Obtener un estudiante por codigo", description = "Busca y retorna los datos de un estudiante usando su codigo unico.")
        @ApiResponse(responseCode = "200", description = "Estudiante encontrado")
        @ApiResponse(responseCode = "404", description = "Estudiante no encontrado", content = @Content(schema = @Schema(hidden = true)))
        public ResponseEntity<EstudianteDTO> getEstudiante(
                        @Parameter(description = "Codigo unico del estudiante", required = true, example = "EST-001") @PathVariable(name = "codigo") final String codigo) {
                return ResponseEntity.ok(estudianteService.get(codigo));
        }

        @PostMapping
        @Operation(summary = "Registrar un nuevo estudiante", description = "Crea un nuevo estudiante en el sistema y retorna su codigo.")
        @ApiResponse(responseCode = "201", description = "Estudiante creado exitosamente")
        @ApiResponse(responseCode = "400", description = "Datos de entrada invalidos o codigo/nombre/email duplicado", content = @Content(schema = @Schema(hidden = true)))
        public ResponseEntity<String> createEstudiante(
                        @RequestBody @Valid final EstudianteDTO estudianteDTO) {
                final String createdCodigo = estudianteService.create(estudianteDTO);
                return new ResponseEntity<>('"' + createdCodigo + '"', HttpStatus.CREATED);
        }

        @PutMapping("/{codigo}")
        @Operation(summary = "Actualizar datos de un estudiante", description = "Actualiza la informacion de un estudiante existente identificado por su codigo.")
        @ApiResponse(responseCode = "200", description = "Estudiante actualizado exitosamente")
        @ApiResponse(responseCode = "400", description = "Datos de entrada invalidos", content = @Content(schema = @Schema(hidden = true)))
        @ApiResponse(responseCode = "404", description = "Estudiante no encontrado", content = @Content(schema = @Schema(hidden = true)))
        public ResponseEntity<String> updateEstudiante(
                        @Parameter(description = "Codigo unico del estudiante", required = true, example = "EST-001") @PathVariable(name = "codigo") final String codigo,
                        @RequestBody @Valid final EstudianteDTO estudianteDTO) {
                estudianteService.update(codigo, estudianteDTO);
                return ResponseEntity.ok('"' + codigo + '"');
        }

        @DeleteMapping("/{codigo}")
        @Operation(summary = "Eliminar un estudiante", description = "Elimina un estudiante del sistema. Si tiene notas asociadas, la operacion sera rechazada.")
        @ApiResponse(responseCode = "204", description = "Estudiante eliminado exitosamente")
        @ApiResponse(responseCode = "404", description = "Estudiante no encontrado", content = @Content(schema = @Schema(hidden = true)))
        @ApiResponse(responseCode = "409", description = "El estudiante tiene notas asociadas y no puede eliminarse", content = @Content(schema = @Schema(hidden = true)))
        public ResponseEntity<Void> deleteEstudiante(
                        @Parameter(description = "Codigo unico del estudiante", required = true, example = "EST-001") @PathVariable(name = "codigo") final String codigo) {
                estudianteService.delete(codigo);
                return ResponseEntity.noContent().build();
        }

        @GetMapping("/top10")
        @Operation(summary = "Top 10 mejores estudiantes", description = "Retorna los 10 estudiantes con mayor promedio ponderado, ordenados de mayor a menor.")
        @ApiResponse(responseCode = "200", description = "Top 10 obtenido exitosamente")
        public ResponseEntity<List<EstudianteDTO>> getTop10() {
                return ResponseEntity.ok(estudianteService.top10());
        }

        @GetMapping("/filtrar")
        @Operation(summary = "Filtrar estudiantes por promedio minimo", description = "Retorna los estudiantes cuyo promedio ponderado es mayor o igual al valor indicado.")
        @ApiResponse(responseCode = "200", description = "Lista filtrada obtenida exitosamente")
        public ResponseEntity<List<EstudianteDTO>> filtrarPorPromedio(
                        @Parameter(description = "Promedio minimo a filtrar", required = true, example = "14.0") @RequestParam(name = "promedioMinimo") final double promedioMinimo) {
                return ResponseEntity.ok(estudianteService.filtrarPorPromedioMinimo(promedioMinimo));
        }

        @GetMapping("/{codigo}/reglas")
        @Operation(summary = "Evaluar reglas academicas de un estudiante", description = "Ejecuta el motor de reglas sobre el estudiante indicado y retorna todas las alertas o reconocimientos aplicables.")
        @ApiResponse(responseCode = "200", description = "Evaluacion realizada exitosamente")
        @ApiResponse(responseCode = "404", description = "Estudiante no encontrado", content = @Content(schema = @Schema(hidden = true)))
        public ResponseEntity<List<ResultadoEvaluacion>> evaluarReglas(
                        @Parameter(description = "Codigo unico del estudiante", required = true, example = "EST-001") @PathVariable(name = "codigo") final String codigo) {
                return ResponseEntity.ok(estudianteService.evaluarReglas(codigo));
        }

}