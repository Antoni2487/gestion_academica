package com.academia.gestion.sistema_academico.rules.core;

public record ResultadoEvaluacion(
                String regla,
                String mensaje,
                NivelAlerta nivel) {
}