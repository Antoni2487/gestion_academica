package com.academia.gestion.sistema_academico.rules.impl;

import com.academia.gestion.sistema_academico.estudiante.Estudiante;
import com.academia.gestion.sistema_academico.rules.core.CalculadoraPromedio;
import com.academia.gestion.sistema_academico.rules.core.NivelAlerta;
import com.academia.gestion.sistema_academico.rules.core.ReglaAcademica;
import com.academia.gestion.sistema_academico.rules.core.ResultadoEvaluacion;

public class ReglaRiesgoAlto implements ReglaAcademica {

    @Override
    public ResultadoEvaluacion evaluar(Estudiante estudiante) {
        double promedio = CalculadoraPromedio.calcular(estudiante);
        if (promedio < 11) {
            return new ResultadoEvaluacion(
                    "ReglaRiesgoAlto",
                    "Riesgo alto de reprobación, promedio " + promedio,
                    NivelAlerta.CRITICO);
        }
        return null;
    }
}