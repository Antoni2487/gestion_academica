package com.academia.gestion.sistema_academico.reporte;

import com.academia.gestion.sistema_academico.estudiante.Estudiante;
import com.academia.gestion.sistema_academico.estudiante.EstudianteRepository;
import com.academia.gestion.sistema_academico.rules.MotorDeReglas;
import com.academia.gestion.sistema_academico.rules.core.CalculadoraPromedio;
import com.academia.gestion.sistema_academico.rules.core.NivelAlerta;
import com.academia.gestion.sistema_academico.rules.core.ResultadoEvaluacion;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class ReporteService {

        private final EstudianteRepository estudianteRepository;
        private final MotorDeReglas motorDeReglas;

        public ReporteService(final EstudianteRepository estudianteRepository,
                        final MotorDeReglas motorDeReglas) {
                this.estudianteRepository = estudianteRepository;
                this.motorDeReglas = motorDeReglas;
        }

        public ReporteDTO generarReporteGeneral() {
                final List<Estudiante> estudiantes = estudianteRepository.findAll();

                final double promedioGeneral = estudiantes.stream()
                                .mapToDouble(CalculadoraPromedio::calcular)
                                .average()
                                .orElse(0);

                final Map<NivelAlerta, Long> conteoXNivel = estudiantes.stream()
                                .flatMap(estudiante -> motorDeReglas.evaluarTodas(estudiante).stream())
                                .collect(Collectors.groupingBy(ResultadoEvaluacion::nivel, Collectors.counting()));

                final List<String> alumnosEnRiesgo = estudiantes.stream()
                                .filter(estudiante -> motorDeReglas.evaluarTodas(estudiante).stream()
                                                .anyMatch(resultado -> resultado.nivel() == NivelAlerta.CRITICO))
                                .map(Estudiante::getCodigo)
                                .toList();

                final List<String> alumnosDestacados = estudiantes.stream()
                                .filter(estudiante -> motorDeReglas.evaluarTodas(estudiante).stream()
                                                .anyMatch(resultado -> resultado.nivel() == NivelAlerta.RECONOCIMIENTO))
                                .map(Estudiante::getCodigo)
                                .toList();

                final ReporteDTO dto = new ReporteDTO();
                dto.setTotalEstudiantes(estudiantes.size());
                dto.setPromedioGeneral(promedioGeneral);
                dto.setConteoPorNivel(conteoXNivel);
                dto.setAlumnosEnRiesgo(alumnosEnRiesgo);
                dto.setAlumnosDestacados(alumnosDestacados);
                return dto;
        }
}