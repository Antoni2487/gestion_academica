package com.academia.gestion.sistema_academico.nota;

import com.academia.gestion.sistema_academico.estudiante.Estudiante;
import com.academia.gestion.sistema_academico.estudiante.EstudianteRepository;
import com.academia.gestion.sistema_academico.events.BeforeDeleteEstudiante;
import com.academia.gestion.sistema_academico.util.NotFoundException;
import com.academia.gestion.sistema_academico.util.ReferencedException;
import java.util.List;
import org.springframework.context.event.EventListener;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

@Service
public class NotaService {

    private final NotaRepository notaRepository;
    private final EstudianteRepository estudianteRepository;

    public NotaService(final NotaRepository notaRepository,
            final EstudianteRepository estudianteRepository) {
        this.notaRepository = notaRepository;
        this.estudianteRepository = estudianteRepository;
    }

    public List<NotaDTO> findAll() {
        final List<Nota> notas = notaRepository.findAll(Sort.by("id"));
        return notas.stream()
                .map(nota -> mapToDTO(nota, new NotaDTO()))
                .toList();
    }

    public NotaDTO get(final Long id) {
        return notaRepository.findById(id)
                .map(nota -> mapToDTO(nota, new NotaDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Long create(final NotaDTO notaDTO) {
        final Nota nota = new Nota();
        mapToEntity(notaDTO, nota);
        return notaRepository.save(nota).getId();
    }

    public void update(final Long id, final NotaDTO notaDTO) {
        final Nota nota = notaRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(notaDTO, nota);
        notaRepository.save(nota);
    }

    public void delete(final Long id) {
        final Nota nota = notaRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        notaRepository.delete(nota);
    }

    private NotaDTO mapToDTO(final Nota nota, final NotaDTO notaDTO) {
        notaDTO.setId(nota.getId());
        notaDTO.setCurso(nota.getCurso());
        notaDTO.setValor(nota.getValor());
        notaDTO.setCreditos(nota.getCreditos());
        notaDTO.setTipo(nota.getTipo());
        notaDTO.setSemestre(nota.getSemestre());
        notaDTO.setNotaEstudiante(nota.getNotaEstudiante() == null ? null : nota.getNotaEstudiante().getCodigo());
        return notaDTO;
    }

    private Nota mapToEntity(final NotaDTO notaDTO, final Nota nota) {
        nota.setCurso(notaDTO.getCurso());
        nota.setValor(notaDTO.getValor());
        nota.setCreditos(notaDTO.getCreditos());
        nota.setTipo(notaDTO.getTipo());
        nota.setSemestre(notaDTO.getSemestre());
        final Estudiante notaEstudiante = notaDTO.getNotaEstudiante() == null ? null : estudianteRepository.findById(notaDTO.getNotaEstudiante())
                .orElseThrow(() -> new NotFoundException("notaEstudiante not found"));
        nota.setNotaEstudiante(notaEstudiante);
        return nota;
    }

    @EventListener(BeforeDeleteEstudiante.class)
    public void on(final BeforeDeleteEstudiante event) {
        final ReferencedException referencedException = new ReferencedException();
        final Nota notaEstudianteNota = notaRepository.findFirstByNotaEstudianteCodigo(event.getCodigo());
        if (notaEstudianteNota != null) {
            referencedException.setKey("estudiante.nota.notaEstudiante.referenced");
            referencedException.addParam(notaEstudianteNota.getId());
            throw referencedException;
        }
    }
}