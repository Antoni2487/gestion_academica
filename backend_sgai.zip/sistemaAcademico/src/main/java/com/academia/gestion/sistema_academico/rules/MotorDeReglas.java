package com.academia.gestion.sistema_academico.rules;

import com.academia.gestion.sistema_academico.estudiante.Estudiante;
import com.academia.gestion.sistema_academico.rules.core.ReglaAcademica;
import com.academia.gestion.sistema_academico.rules.core.ResultadoEvaluacion;
import com.academia.gestion.sistema_academico.rules.impl.*;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class MotorDeReglas {

    private final List<ReglaAcademica> reglas = List.of(
            new ReglaAprobacion(),
            new ReglaDesaprobacion(),
            new ReglaRiesgoAlto(),
            new ReglaRiesgoMedio(),
            new ReglaAlumnoDestacado(),
            new ReglaTutoria(),
            new ReglaReconocimiento());

    public List<ResultadoEvaluacion> evaluarTodas(Estudiante estudiante) {
        return reglas.stream()
                .map(regla -> regla.evaluar(estudiante))
                .filter(resultado -> resultado != null)
                .toList();
    }
}