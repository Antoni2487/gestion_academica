package com.academia.gestion.sistema_academico.nota;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "/api/notas", produces = MediaType.APPLICATION_JSON_VALUE)
@Tag(name = "Notas", description = "Gestión de notas académicas de los estudiantes")
public class NotaResource {

    private final NotaService notaService;

    public NotaResource(final NotaService notaService) {
        this.notaService = notaService;
    }

    @GetMapping
    @Operation(
            summary = "Listar todas las notas",
            description = "Retorna la lista completa de notas académicas ordenadas por id."
    )
    @ApiResponse(responseCode = "200", description = "Lista de notas obtenida exitosamente")
    public ResponseEntity<List<NotaDTO>> getAllNotas() {
        return ResponseEntity.ok(notaService.findAll());
    }

    @GetMapping("/{id}")
    @Operation(
            summary = "Obtener una nota por id",
            description = "Busca y retorna los datos de una nota académica usando su identificador."
    )
    @ApiResponse(responseCode = "200", description = "Nota encontrada")
    @ApiResponse(responseCode = "404", description = "Nota no encontrada",
            content = @Content(schema = @Schema(hidden = true)))
    public ResponseEntity<NotaDTO> getNota(
            @Parameter(description = "Identificador único de la nota", required = true, example = "1")
            @PathVariable(name = "id") final Long id) {
        return ResponseEntity.ok(notaService.get(id));
    }

    @PostMapping
    @Operation(
            summary = "Registrar una nueva nota",
            description = "Crea una nueva nota académica asociada a un estudiante existente y retorna su id."
    )
    @ApiResponse(responseCode = "201", description = "Nota creada exitosamente")
    @ApiResponse(responseCode = "400", description = "Datos de entrada inválidos",
            content = @Content(schema = @Schema(hidden = true)))
    @ApiResponse(responseCode = "404", description = "Estudiante referenciado no encontrado",
            content = @Content(schema = @Schema(hidden = true)))
    public ResponseEntity<Long> createNota(@RequestBody @Valid final NotaDTO notaDTO) {
        final Long createdId = notaService.create(notaDTO);
        return new ResponseEntity<>(createdId, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    @Operation(
            summary = "Actualizar una nota",
            description = "Actualiza los datos de una nota académica existente identificada por su id."
    )
    @ApiResponse(responseCode = "200", description = "Nota actualizada exitosamente")
    @ApiResponse(responseCode = "400", description = "Datos de entrada inválidos",
            content = @Content(schema = @Schema(hidden = true)))
    @ApiResponse(responseCode = "404", description = "Nota o estudiante no encontrado",
            content = @Content(schema = @Schema(hidden = true)))
    public ResponseEntity<Long> updateNota(
            @Parameter(description = "Identificador único de la nota", required = true, example = "1")
            @PathVariable(name = "id") final Long id,
            @RequestBody @Valid final NotaDTO notaDTO) {
        notaService.update(id, notaDTO);
        return ResponseEntity.ok(id);
    }

    @DeleteMapping("/{id}")
    @Operation(
            summary = "Eliminar una nota",
            description = "Elimina una nota académica del sistema por su id."
    )
    @ApiResponse(responseCode = "204", description = "Nota eliminada exitosamente")
    @ApiResponse(responseCode = "404", description = "Nota no encontrada",
            content = @Content(schema = @Schema(hidden = true)))
    public ResponseEntity<Void> deleteNota(
            @Parameter(description = "Identificador único de la nota", required = true, example = "1")
            @PathVariable(name = "id") final Long id) {
        notaService.delete(id);
        return ResponseEntity.noContent().build();
    }

}
