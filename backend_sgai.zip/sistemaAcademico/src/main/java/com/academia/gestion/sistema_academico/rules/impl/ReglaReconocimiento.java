package com.academia.gestion.sistema_academico.rules.impl;

import com.academia.gestion.sistema_academico.estudiante.Estudiante;
import com.academia.gestion.sistema_academico.nota.Nota;
import com.academia.gestion.sistema_academico.rules.core.CalculadoraPromedio;
import com.academia.gestion.sistema_academico.rules.core.NivelAlerta;
import com.academia.gestion.sistema_academico.rules.core.ReglaAcademica;
import com.academia.gestion.sistema_academico.rules.core.ResultadoEvaluacion;

import java.util.Comparator;
import java.util.Optional;

public class ReglaReconocimiento implements ReglaAcademica {

    @Override
    public ResultadoEvaluacion evaluar(Estudiante estudiante) {
        String semestreActual = estudiante.getSemestre();

        Optional<String> semestreAnterior = estudiante.getEstudiante().stream()
                .map(Nota::getSemestre)
                .filter(s -> s != null && !s.equals(semestreActual))
                .max(Comparator.naturalOrder());

        if (semestreAnterior.isEmpty()) {
            return null;
        }

        double promedioActual = CalculadoraPromedio.calcular(estudiante, semestreActual);
        double promedioAnterior = CalculadoraPromedio.calcular(estudiante, semestreAnterior.get());

        if (promedioActual - promedioAnterior >= 3) {
            return new ResultadoEvaluacion(
                    "ReglaReconocimiento",
                    "Mejora de " + (promedioActual - promedioAnterior) + " puntos respecto al semestre anterior",
                    NivelAlerta.RECONOCIMIENTO);
        }
        return null;
    }
}
