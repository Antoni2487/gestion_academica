package com.academia.gestion.sistema_academico.events;

import lombok.AllArgsConstructor;
import lombok.Getter;


@Getter
@AllArgsConstructor
public class BeforeDeleteEstudiante {

    private String codigo;

}
