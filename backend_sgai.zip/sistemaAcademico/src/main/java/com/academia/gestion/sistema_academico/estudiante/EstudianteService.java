package com.academia.gestion.sistema_academico.estudiante;

import com.academia.gestion.sistema_academico.events.BeforeDeleteEstudiante;
import com.academia.gestion.sistema_academico.rules.MotorDeReglas;
import com.academia.gestion.sistema_academico.rules.core.CalculadoraPromedio;
import com.academia.gestion.sistema_academico.rules.core.ResultadoEvaluacion;
import com.academia.gestion.sistema_academico.util.NotFoundException;
import java.util.Comparator;
import java.util.List;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class EstudianteService {

    private final EstudianteRepository estudianteRepository;
    private final ApplicationEventPublisher publisher;
    private final MotorDeReglas motorDeReglas;

    public EstudianteService(final EstudianteRepository estudianteRepository,
            final ApplicationEventPublisher publisher,
            final MotorDeReglas motorDeReglas) {
        this.estudianteRepository = estudianteRepository;
        this.publisher = publisher;
        this.motorDeReglas = motorDeReglas;
    }

    public List<EstudianteDTO> findAll() {
        final List<Estudiante> estudiantes = estudianteRepository.findAll(Sort.by("codigo"));
        return estudiantes.stream()
                .map(estudiante -> mapToDTO(estudiante, new EstudianteDTO()))
                .toList();
    }

    public EstudianteDTO get(final String codigo) {
        return estudianteRepository.findById(codigo)
                .map(estudiante -> mapToDTO(estudiante, new EstudianteDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public String create(final EstudianteDTO estudianteDTO) {
        final Estudiante estudiante = new Estudiante();
        mapToEntity(estudianteDTO, estudiante);
        estudiante.setCodigo(estudianteDTO.getCodigo());
        return estudianteRepository.save(estudiante).getCodigo();
    }

    public void update(final String codigo, final EstudianteDTO estudianteDTO) {
        final Estudiante estudiante = estudianteRepository.findById(codigo)
                .orElseThrow(NotFoundException::new);
        mapToEntity(estudianteDTO, estudiante);
        estudianteRepository.save(estudiante);
    }

    public void delete(final String codigo) {
        final Estudiante estudiante = estudianteRepository.findById(codigo)
                .orElseThrow(NotFoundException::new);
        publisher.publishEvent(new BeforeDeleteEstudiante(codigo));
        estudianteRepository.delete(estudiante);
    }

    private EstudianteDTO mapToDTO(final Estudiante estudiante, final EstudianteDTO estudianteDTO) {
        estudianteDTO.setCodigo(estudiante.getCodigo());
        estudianteDTO.setNombre(estudiante.getNombre());
        estudianteDTO.setApellido(estudiante.getApellido());
        estudianteDTO.setEmail(estudiante.getEmail());
        estudianteDTO.setSemestre(estudiante.getSemestre());
        return estudianteDTO;
    }

    private Estudiante mapToEntity(final EstudianteDTO estudianteDTO, final Estudiante estudiante) {
        estudiante.setNombre(estudianteDTO.getNombre());
        estudiante.setApellido(estudianteDTO.getApellido());
        estudiante.setEmail(estudianteDTO.getEmail());
        estudiante.setSemestre(estudianteDTO.getSemestre());
        return estudiante;
    }

    public boolean codigoExists(final String codigo) {
        return estudianteRepository.existsByCodigoIgnoreCase(codigo);
    }

    public boolean nombreExists(final String nombre) {
        return estudianteRepository.existsByNombreIgnoreCase(nombre);
    }

    public boolean emailExists(final String email) {
        return estudianteRepository.existsByEmailIgnoreCase(email);
    }

    public List<EstudianteDTO> top10() {
        return estudianteRepository.findAll().stream()
                .sorted(Comparator.comparingDouble((Estudiante estudiante) -> CalculadoraPromedio.calcular(estudiante)).reversed())
                .limit(10)
                .map(estudiante -> mapToDTO(estudiante, new EstudianteDTO()))
                .toList();
    }

    public List<EstudianteDTO> filtrarPorPromedioMinimo(final double promedioMinimo) {
        return estudianteRepository.findAll().stream()
                .filter(estudiante -> CalculadoraPromedio.calcular(estudiante) >= promedioMinimo)
                .map(estudiante -> mapToDTO(estudiante, new EstudianteDTO()))
                .toList();
    }

    public List<ResultadoEvaluacion> evaluarReglas(final String codigo) {
        final Estudiante estudiante = estudianteRepository.findById(codigo)
                .orElseThrow(NotFoundException::new);
        return motorDeReglas.evaluarTodas(estudiante);
    }

}