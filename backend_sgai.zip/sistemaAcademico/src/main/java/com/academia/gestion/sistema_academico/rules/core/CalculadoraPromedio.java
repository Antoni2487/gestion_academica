package com.academia.gestion.sistema_academico.rules.core;

import com.academia.gestion.sistema_academico.estudiante.Estudiante;
import com.academia.gestion.sistema_academico.nota.Nota;

public class CalculadoraPromedio {

    private CalculadoraPromedio() {
    }

    public static double calcular(Estudiante estudiante) {
        double sumaPonderada = 0;
        int sumaCreditos = 0;
        for (Nota nota : estudiante.getEstudiante()) {
            sumaPonderada += nota.getValor() * nota.getCreditos();
            sumaCreditos += nota.getCreditos();
        }
        return sumaCreditos == 0 ? 0 : sumaPonderada / sumaCreditos;
    }

    public static double calcular(Estudiante estudiante, String semestre) {
        double sumaPonderada = 0;
        int sumaCreditos = 0;
        for (Nota nota : estudiante.getEstudiante()) {
            if (semestre.equals(nota.getSemestre())) {
                sumaPonderada += nota.getValor() * nota.getCreditos();
                sumaCreditos += nota.getCreditos();
            }
        }
        return sumaCreditos == 0 ? 0 : sumaPonderada / sumaCreditos;
    }

    public static long contarCursosDesaprobados(Estudiante estudiante, double notaMinima) {
        long contador = 0;
        for (Nota nota : estudiante.getEstudiante()) {
            if (nota.getValor() < notaMinima) {
                contador++;
            }
        }
        return contador;
    }
}