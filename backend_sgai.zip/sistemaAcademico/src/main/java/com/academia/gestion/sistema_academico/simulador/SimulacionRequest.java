package com.academia.gestion.sistema_academico.simulador;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SimulacionRequest {

    @NotNull
    @Size(max = 255)
    private String curso;

    @NotNull
    private Double valor;

    @NotNull
    private Integer creditos;
}