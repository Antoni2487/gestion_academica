package com.academia.gestion.sistema_academico.reporte;

import com.academia.gestion.sistema_academico.rules.core.NivelAlerta;
import lombok.Getter;
import lombok.Setter;

import java.util.List;
import java.util.Map;

@Getter
@Setter
public class ReporteDTO {

    private int totalEstudiantes;
    private double promedioGeneral;
    private Map<NivelAlerta, Long> conteoPorNivel;
    private List<String> alumnosEnRiesgo;
    private List<String> alumnosDestacados;
}
