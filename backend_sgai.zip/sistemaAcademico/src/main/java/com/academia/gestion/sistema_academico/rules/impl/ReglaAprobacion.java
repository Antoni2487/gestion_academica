package com.academia.gestion.sistema_academico.rules.impl;

import com.academia.gestion.sistema_academico.estudiante.Estudiante;
import com.academia.gestion.sistema_academico.rules.core.CalculadoraPromedio;
import com.academia.gestion.sistema_academico.rules.core.NivelAlerta;
import com.academia.gestion.sistema_academico.rules.core.ReglaAcademica;
import com.academia.gestion.sistema_academico.rules.core.ResultadoEvaluacion;

public class ReglaAprobacion implements ReglaAcademica {

    @Override
    public ResultadoEvaluacion evaluar(Estudiante estudiante) {
        double promedio = CalculadoraPromedio.calcular(estudiante);
        if (promedio >= 14) {
            return new ResultadoEvaluacion(
                    "ReglaAprobacion",
                    "Estudiante aprobado con promedio " + promedio,
                    NivelAlerta.INFO);
        }
        return null;
    }
}