package com.academia.gestion.sistema_academico.rules.core;

import com.academia.gestion.sistema_academico.estudiante.Estudiante;

public interface ReglaAcademica {
    ResultadoEvaluacion evaluar(Estudiante estudiante);
}
