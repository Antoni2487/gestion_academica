package com.academia.gestion.sistema_academico.nota;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class NotaDTO {

    private Long id;

    @NotNull
    @Size(max = 255)
    private String curso;

    @NotNull
    private Double valor;

    @NotNull
    private Integer creditos;

    @NotNull
    @Size(max = 255)
    private String tipo;

    @NotNull
    @Size(max = 255)
    private String semestre;

    @NotNull
    @Size(max = 255)
    private String notaEstudiante;

}