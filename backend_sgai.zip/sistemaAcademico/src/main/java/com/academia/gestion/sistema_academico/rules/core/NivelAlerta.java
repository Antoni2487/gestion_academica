package com.academia.gestion.sistema_academico.rules.core;

public enum NivelAlerta {
    INFO,
    ADVERTENCIA,
    CRITICO,
    RECONOCIMIENTO
}