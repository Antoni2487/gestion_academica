package com.academia.gestion.sistema_academico.estudiante;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class EstudianteDTO {

    @Size(max = 255)
    @EstudianteCodigoValid
    private String codigo;

    @NotNull
    @Size(max = 255)
    @EstudianteNombreUnique
    private String nombre;

    @NotNull
    @Size(max = 255)
    private String apellido;

    @NotNull
    @Size(max = 255)
    @EstudianteEmailUnique
    private String email;

    @NotNull
    @Size(max = 255)
    private String semestre;

}
