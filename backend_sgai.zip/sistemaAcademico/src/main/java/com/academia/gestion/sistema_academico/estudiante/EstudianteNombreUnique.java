package com.academia.gestion.sistema_academico.estudiante;

import static java.lang.annotation.ElementType.ANNOTATION_TYPE;
import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Constraint;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import jakarta.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.Map;
import org.springframework.web.servlet.HandlerMapping;


/**
 * Validate that the nombre value isn't taken yet.
 */
@Target({ FIELD, METHOD, ANNOTATION_TYPE })
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Constraint(
        validatedBy = EstudianteNombreUnique.EstudianteNombreUniqueValidator.class
)
public @interface EstudianteNombreUnique {

    String message() default "{Exists.estudiante.nombre}";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    class EstudianteNombreUniqueValidator implements ConstraintValidator<EstudianteNombreUnique, String> {

        private final EstudianteService estudianteService;
        private final HttpServletRequest request;

        public EstudianteNombreUniqueValidator(final EstudianteService estudianteService,
                final HttpServletRequest request) {
            this.estudianteService = estudianteService;
            this.request = request;
        }

        @Override
        public boolean isValid(final String value, final ConstraintValidatorContext cvContext) {
            if (value == null) {
                // no value present
                return true;
            }
            @SuppressWarnings("unchecked") final Map<String, String> pathVariables =
                    ((Map<String, String>)request.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE));
            final String currentId = pathVariables.get("codigo");
            if (currentId != null && value.equalsIgnoreCase(estudianteService.get(currentId).getNombre())) {
                // value hasn't changed
                return true;
            }
            return !estudianteService.nombreExists(value);
        }

    }

}
